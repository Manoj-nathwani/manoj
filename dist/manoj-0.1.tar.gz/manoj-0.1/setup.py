from distutils.core import setup
setup(
  name = 'manoj',
  packages = ['manoj'], # this must be the same as the name above
  version = '0.1',
  description = 'A random test lib',
  author = 'Manoj Nathwani',
  url = 'https://github.com/Manoj-nathwani/pip-install-manoj',
)
