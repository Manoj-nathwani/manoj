class Projects:
    def __init__(self):
        self.all_projects = ['project 1', 'project 2', 'project 3']


    def print_projects(self):
        print('Printing projects...')
        for project in self.all_projects:
            print(project)
